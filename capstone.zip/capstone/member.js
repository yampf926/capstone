// ==========================================================
// 💡 쿠키 관련 유틸리티 함수
// ==========================================================

// 쿠키 값을 가져오는 함수
function getCookie(name) {
    const searchName = name + '=';
    const decodedCookie = decodeURIComponent(document.cookie);
    const cookieArray = decodedCookie.split(';');

    for (let i = 0; i < cookieArray.length; i++) {
        let cookie = cookieArray[i].trim();
        if (cookie.indexOf(searchName) === 0) {
            return cookie.substring(searchName.length, cookie.length);
        }
    }
    return null;
}

// 로그인 상태 쿠키 설정 함수
function setLoginCookie(value, days) {
    let expires = "";
    if (days) {
        const date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toUTCString();
    }
    // 'loggedIn' 이름으로 쿠키 설정/삭제
    document.cookie = "loggedIn=" + (value || "") + expires + "; path=/; SameSite=Lax";
}


// ==========================================================
// 💡 랭킹 관련 유틸리티 함수
// ==========================================================

/**
 * 시간을 분:초.밀리초 형식에서 분:초 형식으로 포맷팅합니다.
 * @param {number} timeInSeconds - 초 단위 시간 (소수점 포함)
 * @returns {string} "M분 S초" 형식의 문자열
 */
function formatTime(timeInSeconds) {
    if (typeof timeInSeconds !== 'number' || isNaN(timeInSeconds)) {
        return '기록 없음';
    }
    // 소수점 이하 버림 (초 단위까지만 표시)
    const timeFloor = Math.floor(timeInSeconds); 
    const minutes = Math.floor(timeFloor / 60);
    const seconds = timeFloor % 60;
    
    // 두 자리 숫자로 표시되도록 0을 채움 (선택 사항)
    const formattedSeconds = seconds < 10 ? '0' + seconds : seconds;
    
    return `${minutes}:${formattedSeconds}`; // "M:SS" 형식으로 시안과 유사하게 변경
}

// ==========================================================
// 💡 랭킹 데이터 표시 함수 (rank.html 전용)
// ==========================================================

async function fetchAndDisplayRanks() {
    const listContainer = document.getElementById('rank_list_container');
    const myRankItem = document.getElementById('my_rank_item');
    if (!listContainer || !myRankItem) return;

    // 초기 로딩 상태
    listContainer.innerHTML = '<div class="rank-item loading" style="text-align: center; justify-content: center;">랭킹 정보를 불러오는 중...</div>';
    myRankItem.querySelector('.rank-id').textContent = '내 ID';
    myRankItem.querySelector('.rank-time').textContent = '플레이 타임';

    try {
        // 1. 세션 정보를 먼저 가져와 사용자 ID 확인
        let myId = "로그인 필요";
        const sessionRes = await fetch("/session");
        let sessionData = {};
        if (sessionRes.ok) {
            sessionData = await sessionRes.json();
            if (sessionData.loggedIn) {
                myId = sessionData.userId; 
            }
        }

        // 2. 랭킹 데이터 가져오기
        const res = await fetch("/rank"); 
        if (!res.ok) throw new Error("랭킹 서버 응답 오류");
        
        const ranks = await res.json();
        
        listContainer.innerHTML = ''; // 기존 내용 지우기
        let myRecord = null; // 내 기록 저장 변수
        
        // 순위 매기기 및 목록 생성
        ranks.forEach((user, index) => {
            // 동점자 순위 계산
            const currentRank = (index > 0 && user.best_time === ranks[index - 1].best_time) 
                                ? ranks[index - 1].rank : (index + 1);
            user.rank = currentRank; 
            
            // 내 기록 찾기
            if (user.id === myId) {
                myRecord = user;
            }

            // 랭킹 아이템 생성
            const item = document.createElement('div');
            item.className = 'rank-item';
            
            // 1, 2, 3등 특별 스타일 (선택 사항: CSS에서 처리)
            // if (currentRank <= 3) item.classList.add('top-rank'); 

            item.innerHTML = `
                <div class="rank-num">${currentRank}</div>
                <div class="rank-profile">
                    <img src="profile.png" alt="Profile" class="profile-icon">
                </div>
                <div class="rank-info">
                    <span class="rank-id">${user.id}</span>
                    <span class="rank-time">${formatTime(user.best_time)}</span>
                </div>
            `;
            
            listContainer.appendChild(item);
        });
        
        if (ranks.length === 0) {
            listContainer.innerHTML = '<div class="rank-item loading" style="text-align: center; justify-content: center;">아직 랭킹 기록이 없습니다.</div>';
        }

        // 3. 하단 고정 내 랭킹 정보 업데이트
        if (myRecord) {
            myRankItem.querySelector('.rank-num').textContent = myRecord.rank;
            myRankItem.querySelector('.rank-id').textContent = myId;
            myRankItem.querySelector('.rank-time').textContent = formatTime(myRecord.best_time);
        } else if (sessionData.loggedIn) {
            myRankItem.querySelector('.rank-num').textContent = (ranks.length + 1) + '등';
            myRankItem.querySelector('.rank-id').textContent = myId;
            myRankItem.querySelector('.rank-time').textContent = '기록 없음';
        } else {
            myRankItem.querySelector('.rank-num').textContent = '로그인';
            myRankItem.querySelector('.rank-id').textContent = '확인하세요';
            myRankItem.querySelector('.rank-time').textContent = '';
        }

    } catch (error) {
        console.error("랭킹 로드 오류:", error);
        listContainer.innerHTML = '<div class="rank-item loading" style="color: red; justify-content: center;">랭킹 정보를 불러오지 못했습니다.</div>';
    }
}


// ==========================================================
// 💡 DOMContentLoaded 이벤트 리스너 (Main Page Logic)
// ==========================================================
document.addEventListener("DOMContentLoaded", () => {
    const startBtn = document.getElementById("start_btn");
    const loginBtn = document.getElementById("login_btn");
    const rankBtn = document.getElementById("rank_btn");

    if (rankBtn) rankBtn.addEventListener("click", () => window.location.href = "rank.html");

    // 💡 [수정] 게임 시작 버튼 클릭 시 세션 유효성 확인 로직 (에러 방지)
    if (startBtn) {
        startBtn.addEventListener("click", async () => {
            const isLoggedIn = getCookie('loggedIn') === 'true';
            
            if (!isLoggedIn) {
                alert("로그인이 필요한 서비스입니다.");
                window.location.href = "login.html";
                return;
            }

            // 서버에 세션 유효성을 최종 확인 (불일치 에러 방지)
            try {
                const res = await fetch("/session");
                const data = await res.json();

                if (data.loggedIn) {
                    window.location.href = "game.html"; // 세션 유효하면 게임 시작
                } else {
                    // 세션 불일치 발생 시 클라이언트 쿠키 삭제 후 로그인 유도
                    alert("로그인 세션이 만료되었습니다. 다시 로그인해주세요.");
                    setLoginCookie('', -1);
                    window.location.href = "login.html";
                }
            } catch (error) {
                console.error("세션 확인 오류:", error);
                alert("서버 통신 오류로 게임을 시작할 수 없습니다.");
            }
        });
    }

    if (loginBtn) {
        // UI 버튼 상태 결정 (쿠키로 빠르게)
        const isLoggedIn = getCookie('loggedIn') === 'true';

        if (isLoggedIn) {
            loginBtn.textContent = "로그아웃";
            loginBtn.onclick = logout_click;
        } else {
            loginBtn.textContent = "로그인";
            loginBtn.onclick = () => window.location.href = "login.html";
        }
        loginBtn.style.visibility = "visible";
    }

    // 💡 [추가] 랭킹 페이지일 때만 랭킹 데이터 로드
    if (document.getElementById('rank_list_container')) {
        fetchAndDisplayRanks();
    }
});


// ==========================================================
// 💡 회원가입 / 로그인 / 로그아웃 함수
// ==========================================================

// 회원가입
async function signup_submit() {
    const id = document.getElementById("signup_id").value.trim();
    const pw = document.getElementById("signup_pw").value.trim();
    const pw2 = document.getElementById("signup_pw2").value.trim();

    if (id.length < 4 || id.length > 10) return alert("아이디는 4~10자 사이여야 합니다.");
    if (pw.length < 4 || pw.length > 10) return alert("비밀번호는 4~10자 사이여야 합니다.");
    if (pw !== pw2) return alert("비밀번호가 일치하지 않습니다.");

    const res = await fetch("/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, pw })
    });

    const data = await res.json();
    alert(data.message);
    if (data.success) window.location.href = "login.html";
}

// 로그인
async function login_submit() {
    const id = document.getElementById("login_id").value.trim();
    const pw = document.getElementById("login_pw").value.trim();

    if (id.length < 4 || id.length > 10) return alert("아이디는 4~10자 사이여야 합니다.");
    if (pw.length < 4 || pw.length > 10) return alert("비밀번호는 4~10자 사이여야 합니다.");

    const res = await fetch("/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, pw })
    });

    const data = await res.json();
    alert(data.message);
    
    // 💡 로그인 성공 시 클라이언트 쿠키 설정
    if (data.success) {
        setLoginCookie('true', 1); // 'loggedIn=true' 쿠키를 1일 동안 유효하게 설정
        window.location.href = "main.html";
    }
}

// 로그아웃
async function logout_click() {
    const ok = confirm("로그아웃하시겠습니까?");
    if (!ok) return;

    const res = await fetch("/logout", { method: "POST" });
    const data = await res.json();
    
    // 💡 로그아웃 성공 시 클라이언트 쿠키 삭제
    setLoginCookie('', -1); // 만료 시간을 과거로 설정하여 쿠키 삭제
    
    alert(data.message);
    // 로그아웃 후 main.html로 이동하여 상태 갱신
    window.location.href = "main.html";
}