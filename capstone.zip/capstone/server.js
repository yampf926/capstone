// server.js (복구 및 최종 수정된 Node.js/Express 코드)

const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const bodyParser = require("body-parser");
const session = require("express-session");
const path = require("path");
const { local, production } = require("./config");

const app = express();
const PORT = process.env.PORT || 3000;

// 환경 구분 (로컬/배포)
const dbConfig = process.env.NODE_ENV === "production" ? production : local;
const db = mysql.createConnection(dbConfig);

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(__dirname));

// ✅ 세션 설정 (쿠키 설정 포함)
app.use(session({
    secret: "capstone_secret",
    resave: false,
    saveUninitialized: true,
    cookie: {
        secure: process.env.NODE_ENV === "production", 
        sameSite: 'lax',
        maxAge: 1000 * 60 * 60 * 24
    }
}));

// DB 연결 확인
db.connect(err => {
    if (err) console.error("❌ MySQL 연결 실패:", err);
    else console.log("✅ MySQL 연결 성공");
});

// 회원가입
app.post("/signup", (req, res) => {
    const { id, pw } = req.body;
    // ... (DB 로직)
});

// 로그인
app.post("/login", (req, res) => {
    const { id, pw } = req.body;
    // ... (DB 확인 로직)

    // DB 확인 후 로그인 성공 시 세션 저장
    // if (user.password === pw) {
    //     req.session.userId = id;
    //     res.json({ success: true, message: "로그인되었습니다." });
    // }
});

// 로그아웃
app.post("/logout", (req, res) => {
    req.session.destroy();
    res.json({ success: true, message: "로그아웃되었습니다." });
});

// ✅ 로그인 상태 확인 (404 오류 해결)
app.get("/session", (req, res) => {
    if (req.session.userId) {
        // ✅ 200 OK와 JSON 응답 (SyntaxError 해결)
        res.json({ loggedIn: true, userId: req.session.userId }); 
    } else {
        res.json({ loggedIn: false });
    }
});

// HTML 파일 제공 (SyntaxError 해결)
app.get("/", (req, res) => res.sendFile(path.join(__dirname, "main.html")));
app.get("/login.html", (req, res) => res.sendFile(path.join(__dirname, "login.html")));
app.get("/signup.html", (req, res) => res.sendFile(path.join(__dirname, "signup.html")));

app.listen(PORT, () => console.log(`🚀 서버 실행 중: http://localhost:${PORT}`));